package com.uxpsystems.assignement.controller;

import com.uxpsystems.assignement.models.User;
import com.uxpsystems.assignement.service.UserDetailsServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc

public class UserControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserDetailsServiceImpl userDetailsService;

    @Test
    public void testGetAll() throws Exception {

        User user = new User("ankit","ankit123", "active");
        User user1 = new User("akash","akash123", "active");
        List<User> userList = new ArrayList<>();
        userList.add(user);
        userList.add(user1);

        Mockito.when(userDetailsService.getAllUsers()).thenReturn(userList);

        mockMvc.perform(MockMvcRequestBuilders.get("/assignement/All"))
                .andExpect(status().isOk()).andDo(print());
    }


    @Test
    public void testGetUserById() throws Exception {

        User user = new User("ankit","ankit123", "active");
        Mockito.when(userDetailsService.getUserById(anyLong())).thenReturn(java.util.Optional.of(user));

        mockMvc.perform(MockMvcRequestBuilders.get("/assignement/1")).andDo(print())
                .andExpect(status().isOk());
    }


    @Test
    public void testDeleteUserById() throws Exception {
        User user = new User("ankit","ankit123", "active");
        userDetailsService.addUser(user);
        Mockito.when(userDetailsService.deleteUser(anyLong())).thenReturn("User deleted Successfully!!!");

        mockMvc.perform(MockMvcRequestBuilders.delete("/assignement/1")).andDo(print())
                .andExpect(status().isOk());
    }


    @Test
    public void testAddUserByAdmin() throws Exception {

        User user = new User("ankit","ankit123", "active");
        userDetailsService.addUser(user);
        Mockito.when(userDetailsService.addUser(any(User.class))).thenReturn("User Added Successfully!!!");

        String jsonInput = "{\n" +
                "  \"username\": \"ankit\",\n" +
                "  \"password\": \"ankit123\",\n" +
                "  \"status\": \"active\",\n" +
                "}";

        mockMvc.perform(MockMvcRequestBuilders.post("/assignement/")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonInput))
                .andExpect(status().isOk()).andDo(print());
    }


    @Test
    public void testUpdateUserByAdmin() throws Exception {
        User user = new User("ankit","ankit123", "active");
        userDetailsService.addUser(user);
        Mockito.when(userDetailsService.updateUser(anyString(),any(User.class))).thenReturn("User updated Successfully!!!");
        String jsonInput = "{\n" +
                "  \"username\": \"jerry\",\n" +
                "  \"password\": \"jerry123\",\n" +
                "  \"status\": \"active\",\n" +
                "}";

        mockMvc.perform(MockMvcRequestBuilders.put("/assignement/ankit")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonInput))
                .andExpect(status().isOk()).andDo(print());
    }

}
