package com.uxpsystems.assignement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignementApplicationTests {

    @Test
    void contextLoads() {
    }

}
