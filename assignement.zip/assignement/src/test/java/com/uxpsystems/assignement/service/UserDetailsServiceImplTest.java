package com.uxpsystems.assignement.service;

import com.uxpsystems.assignement.dao.UserRepository;
import com.uxpsystems.assignement.models.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


@RunWith(SpringRunner.class)
@SpringBootTest
public class UserDetailsServiceImplTest {

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @MockBean
    private UserRepository userRepository;

    @Test(expected = NullPointerException.class)
    public void testAddUser(){
        userDetailsService.addUser(new User());
        verify(userRepository, times(1)).save(any(User.class));

    }

    @Test
    public void testGetUserById(){
        User user = new User("ankit","ankit123", "active");
        Mockito.when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
        assertThat(userDetailsService.getUserById(anyLong())).isEqualTo(Optional.of(user));
    }

    @Test
    public void testGetAllUsers(){
        User user = new User("ankit","ankit123", "active");
        User user1 = new User("akash","akash123", "active");
        List<User> userList = new ArrayList<>();
        userList.add(user);
        userList.add(user1);
        Mockito.when(userRepository.findAll()).thenReturn(userList);
        assertThat(userDetailsService.getAllUsers()).isEqualTo(userList);
    }

    @Test
    public void testUpdateUser(){
        User user = new User("ankit","ankit123", "active");
        userRepository.save(user);
        User user1=new User("ank","active");
        userDetailsService.updateUser("ankit",user1);
        verify(userRepository, times(1)).save(any(User.class));

    }
}
