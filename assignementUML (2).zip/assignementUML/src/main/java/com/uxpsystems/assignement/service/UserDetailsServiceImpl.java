package com.uxpsystems.assignement.service;


import com.uxpsystems.assignement.dao.UserRepository;
import com.uxpsystems.assignement.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserDetailsServiceImpl {

    @Autowired
    private UserRepository userRepository;

    @Cacheable("users")
    public User loadUserByUsername(String username)
            throws UsernameNotFoundException {
        User user = userRepository.findUserByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("Could not find user");
        }
        return user;
    }

    public String addUser(User user) {
        if ((userRepository.findUserByUsername(user.getUsername()))==null)
        { userRepository.save(user);
        return "User Added Successfully!!!  With ID--"+(userRepository.findUserByUsername(user.getUsername())).getId();
        }
        return "UserName Already Exists!!";
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @CachePut(value = "users", key = "#userName")
    public String updateUser(String userName, User user) {
        User existingUser = userRepository.findUserByUsername(userName);
        if(existingUser != null) {
            if ((userRepository.findUserByUsername(user.getUsername())) == null) {
                existingUser.setUsername(user.getUsername());
                existingUser.setPassword(user.getPassword());
                existingUser.setStatus(user.getStatus());
                userRepository.save(existingUser);
                return "User Updated";
            }
            return "UserName Already exist";
        }
        return "User Not Found";
    }

    @CacheEvict(value = "users", key = "#id")
    public String deleteUser(Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return "User Deleted SuccessFully";
        }
        return "User Not Exist";
    }
}
