package com.uxpsystems.assignement.dao;
import com.uxpsystems.assignement.models.User;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DbInit implements CommandLineRunner {
    private UserRepository userRepository;

    public DbInit(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) {
        // Delete all
        this.userRepository.deleteAll();

        // Create users
        User jerry = new User("jerry","jerry123","active");
        User admin = new User("admin","admin123","active");

        List<User> users = Arrays.asList(jerry,admin);

        // Save to db
        this.userRepository.saveAll(users);
    }
}