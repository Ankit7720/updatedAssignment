package com.uxpsystems.assignement.controller;

import com.uxpsystems.assignement.models.User;
import com.uxpsystems.assignement.service.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/assignement")
@RestController
public class UserController {

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @PostMapping("/")
    public String addUserByAdmin(@RequestBody User user) {
       return userDetailsService.addUser(user);
    }

    @GetMapping("/All")
    public List<User> getAllUsers(){
        return userDetailsService.getAllUsers();
    }

    @GetMapping("/{id}")
    public Optional<User> getUserById(@PathVariable Long id){

        return userDetailsService.getUserById(id);
    }
    @PutMapping("/{un}")
    public String updateUser(@PathVariable("un") String un, @RequestBody User user){
       return userDetailsService.updateUser(un,user);
    }

    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable("id") Long id){
        return userDetailsService.deleteUser(id);
    }


}